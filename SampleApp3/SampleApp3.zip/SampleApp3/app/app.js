﻿(function(){
    myModule = angular.module('myAngularApplication', []);
}());