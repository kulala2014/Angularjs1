app.controller("MyController", function($scope)
	{
 $scope.article = "Hello there!!I am learning AngularJS";	
});